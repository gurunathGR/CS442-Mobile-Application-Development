package com.christopherhield.gestures;

import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class TouchListener implements View.OnTouchListener {

    private static final String TAG = "TouchListener";
    private float dX, dY;

    @Override
    public boolean onTouch(View view, MotionEvent event) {

        view.performClick(); // For accessibility

        Log.d(TAG, "onTouch: " + event.toString());
        switch (event.getAction()) {

            case MotionEvent.ACTION_DOWN:
                dX = view.getX() - event.getRawX();
                dY = view.getY() - event.getRawY();
                return true;
            case MotionEvent.ACTION_MOVE:
                view.setX(event.getRawX() + dX);
                view.setY(event.getRawY() + dY);
                return true;
        }
        return false;
    }
}
