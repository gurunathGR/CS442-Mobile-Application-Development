package com.christopherhield.gestures;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private ImageView bulb;
    private boolean turnedOn = false;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bulb = findViewById(R.id.imageView);
        bulb.setOnTouchListener(new TouchListener());

        Button button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doClick(v);
            }
        });
        button1.setOnTouchListener(new TouchListener());

        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doClick(v);
            }
        });
        button2.setOnTouchListener(new TouchListener());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.opt_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.spin:
                ObjectAnimator spinAnimator = ObjectAnimator.ofFloat(bulb, "rotation", 0.0f, 1440.0f);
                spinAnimator.setDuration(2000);
                spinAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
                spinAnimator.start();

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void doClick(View v) {
        switch (v.getId()) {
            case R.id.button1:
                if (!turnedOn) {
                    bulb.setImageResource(R.drawable.on);
                    turnedOn = true;
                }
                break;
            case R.id.button2:
                if (turnedOn) {
                    bulb.setImageResource(R.drawable.off);
                    turnedOn = false;
                }
                break;
        }
    }


}