package com.christopherhield.sampleanim;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private ImageView character;
    private ConstraintLayout layout;
    public static int screenHeight;
    public static int screenWidth;

    private Bitmap idleBitmap;
    private Bitmap[] characterWalkBitmaps;
    private boolean busy;

    private Bitmap[] characterFightBitmaps;

    private ImageView backImageA, backImageB;
    private ValueAnimator animator;
    private boolean moving = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupFullScreen();

        getScreenDimensions();

        layout = findViewById(R.id.layout);

        addCharacter();

        addBackImage();

    }

    private void setupFullScreen() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                );
    }

    private void getScreenDimensions() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        screenHeight = displayMetrics.heightPixels;
        screenWidth = displayMetrics.widthPixels;
    }

    private void addCharacter() {

        int[] characterWalkResources = new int[]{R.drawable.run1, R.drawable.run2, R.drawable.run3,
                R.drawable.run4, R.drawable.run5, R.drawable.run6, R.drawable.run7,
                R.drawable.run8};
        characterWalkBitmaps = new Bitmap[characterWalkResources.length];
        for (int i = 0; i < characterWalkResources.length; i++) {
            Bitmap origBitmap = BitmapFactory.decodeResource(getResources(), characterWalkResources[i]);
            characterWalkBitmaps[i] = Bitmap.createScaledBitmap(origBitmap, 482, 406, false);

        }

        ///

        int[] characterFightResources = new int[]{R.drawable.fight1, R.drawable.fight2, R.drawable.fight3,
                R.drawable.fight4, R.drawable.fight5, R.drawable.fight6, R.drawable.fight7};
        characterFightBitmaps = new Bitmap[characterFightResources.length];
        for (int i = 0; i < characterFightResources.length; i++) {
            Bitmap origBitmap = BitmapFactory.decodeResource(getResources(), characterFightResources[i]);
            characterFightBitmaps[i] = Bitmap.createScaledBitmap(origBitmap, 482, 406, false);

        }

        ///

        character = new ImageView(this);

        Bitmap origBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.idle);
        idleBitmap = Bitmap.createScaledBitmap(origBitmap, 482, 406, false);
        character.setImageBitmap(idleBitmap);

        Log.d(TAG, "addCharacter: " + character.getDrawable().getIntrinsicWidth());

        character.setX(0);
        float groundLevel = 180;
        character.setY(screenHeight - idleBitmap.getHeight() - groundLevel);

        layout.addView(character);
    }

    public void doFight(View v) {
        if (busy)
            return;
        busy = true;

        new Thread(new Runnable() {

            @Override
            public void run() {

                for (int c = 0; c < 2; c++) {
                    for (int i = 0; i < characterFightBitmaps.length; i++) {

                        final int index = i;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                character.setImageBitmap(characterFightBitmaps[index]);
                            }
                        });

                        try {
                            Thread.sleep(80);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
                busy = false;
                character.setImageBitmap(idleBitmap);
            }
        }).start();
    }

    public void moveAcross(View v) {

        if (busy)
            return;
        busy = true;

        float endLoc = screenWidth - character.getWidth();

        character.setImageBitmap(characterWalkBitmaps[0]);

        ObjectAnimator characterMover = ObjectAnimator.ofFloat(character, "x", endLoc);
        characterMover.setDuration(2000);
        characterMover.setInterpolator(new LinearInterpolator());
        characterMover.setRepeatCount(1);
        characterMover.setRepeatMode(ValueAnimator.REVERSE);
        characterMover.addListener(new AnimatorListenerAdapter() {

            @Override
            public void onAnimationEnd(Animator animation) {
                Log.d(TAG, "onAnimationEnd: Do Something At End");
                busy = false;
                character.setImageBitmap(idleBitmap);
            }
        });
        characterMover.start();
    }

    public void moveUp(View v) {

        if (busy)
            return;
        busy = true;


        character.setImageBitmap(characterWalkBitmaps[6]);

        ObjectAnimator characterMover = ObjectAnimator.ofFloat(character, "y", 0);
        characterMover.setDuration(1000);
        characterMover.setInterpolator(new LinearInterpolator());
        characterMover.setRepeatCount(1);
        characterMover.setRepeatMode(ValueAnimator.REVERSE);
        characterMover.addListener(new AnimatorListenerAdapter() {

            @Override
            public void onAnimationEnd(Animator animation) {
                Log.d(TAG, "onAnimationEnd: Do Something At End");
                busy = false;
                character.setImageBitmap(idleBitmap);
            }
        });
        characterMover.start();
    }

    public void doRun(View v) {

        if (busy)
            return;
        busy = true;

        new Thread(new Runnable() {

            private float xMod = 30;
            @Override
            public void run() {

                while (true) {
                    for (int i = 0; i < characterWalkBitmaps.length; i++) {

                        final int index = i;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                character.setImageBitmap(characterWalkBitmaps[index]);
                                character.setX(character.getX() + xMod);
                            }
                        });

                        try {
                            Thread.sleep(35);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    if (character.getX() >= screenWidth - character.getWidth()) {
                        character.setImageBitmap(idleBitmap);

                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        character.setX(0);
                        busy = false;
                        break;
                    }
                }
            }
        }).start();
    }


    private void addBackImage() {
        backImageA = new ImageView(this);
        backImageB = new ImageView(this);

        ConstraintLayout layout = findViewById(R.id.layout);
        LinearLayout.LayoutParams params = new LinearLayout
                .LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        backImageA.setLayoutParams(params);
        backImageB.setLayoutParams(params);

        layout.addView(backImageA);
        layout.addView(backImageB);

        Bitmap backBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.background);
        double ratio = (double) screenHeight / (double) backBitmap.getHeight();
        backImageA.setImageBitmap(backBitmap);
        backImageB.setImageBitmap(backBitmap);

        ViewGroup.LayoutParams layoutParams = backImageA.getLayoutParams();
        layoutParams.height = (int) ((double) backBitmap.getHeight() * ratio);
        layoutParams.width = (int) ((double) backBitmap.getWidth() * ratio);

        backImageA.setLayoutParams(layoutParams);
        backImageB.setLayoutParams(layoutParams);

        backImageA.setZ(-1);
        backImageB.setZ(-1);

    }

    public void moveBack(View v) {


        if (moving) {
            animator.pause();
            busy = false;
            moving = false;
            return;
        }

        if (busy)
            return;
        busy = true;
        moving = true;

        long duration = 3000; // 3 seconds

        animator = ValueAnimator.ofFloat(1.0f, 0.0f);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.setDuration(duration);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                final float progress = (float) animation.getAnimatedValue();
                Log.d(TAG, "onAnimationUpdate: " + progress);
                final float width = backImageA.getWidth();
                final float translationX = width * progress;
                backImageA.setTranslationX(translationX);
                backImageB.setTranslationX(translationX - width);
            }
        });
        animator.start();

        new Thread(new Runnable() {

            @Override
            public void run() {
                while (moving) {
                    for (int i = 0; i < characterWalkBitmaps.length; i++) {

                        if (!moving)
                            break;

                        final int index = i;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                character.setImageBitmap(characterWalkBitmaps[index]);
                            }
                        });

                        try {
                            Thread.sleep(35);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
                character.setImageBitmap(idleBitmap);

            }
        }).start();
    }



}
