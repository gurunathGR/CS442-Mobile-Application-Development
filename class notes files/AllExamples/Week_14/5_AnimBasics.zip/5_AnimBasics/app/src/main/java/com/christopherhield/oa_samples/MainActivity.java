package com.christopherhield.oa_samples;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ImageView fishImage;
    private TextView textView;
    public static int screenHeight;
    public static int screenWidth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        screenHeight = displayMetrics.heightPixels;
        screenWidth = displayMetrics.widthPixels;

        fishImage = findViewById(R.id.fishImage);

    }

    public void doXMove(View v) {

        ObjectAnimator animator =
                ObjectAnimator.ofFloat(
                        fishImage, "x",
                        screenWidth - fishImage.getWidth());
        animator.setDuration(2000);
        //animator.setInterpolator(new LinearInterpolator());
        animator.setRepeatCount(1);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        animator.addListener(new AnimatorListenerAdapter() {

            @Override
            public void onAnimationRepeat(Animator animation) {
                textView.setText(R.string.rev_x);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                textView.setText(R.string.done_x);
            }
        });
        textView.setText(R.string.move_x);
        animator.start();
    }

    public void doYMove(View v) {

        ObjectAnimator animator =
                ObjectAnimator.ofFloat(fishImage, "y", screenHeight - fishImage.getHeight() * 2);
        animator.setDuration(1000);
        //animator.setInterpolator(new LinearInterpolator());
        animator.setRepeatCount(1);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        animator.addListener(new AnimatorListenerAdapter() {

            @Override
            public void onAnimationRepeat(Animator animation) {
                textView.setText(R.string.rev_y);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                textView.setText(R.string.done_y);
            }
        });
        textView.setText(R.string.move_y);
        animator.start();
    }

    public void doAlpha(View v) {

        ObjectAnimator animator =
                ObjectAnimator.ofFloat(fishImage, "alpha", 1.0f, 0.0f);
        animator.setDuration(3000);
        animator.setInterpolator(new LinearInterpolator());
        animator.setRepeatCount(1);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        animator.addListener(new AnimatorListenerAdapter() {

            @Override
            public void onAnimationRepeat(Animator animation) {
                textView.setText(R.string.rev_alpha);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                textView.setText(R.string.done_alpha);
            }
        });
        textView.setText(R.string.dec_alpha);
        animator.start();
    }

    public void doRotate(View v) {

        ObjectAnimator animator =
                ObjectAnimator.ofFloat(fishImage, "rotation", 0f, 720f);
        animator.setDuration(1000);
        animator.setInterpolator(new LinearInterpolator());
        animator.setRepeatCount(1);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        animator.addListener(new AnimatorListenerAdapter() {

            @Override
            public void onAnimationRepeat(Animator animation) {
                textView.setText(R.string.rev_rot);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                textView.setText(R.string.done_rot);
            }
        });
        textView.setText(R.string.start_rot);
        animator.start();
    }

    public void doScale(View v) {

        AnimatorSet animSet = new AnimatorSet();

        ObjectAnimator animator1 =
                ObjectAnimator.ofFloat(fishImage, "scaleX", 1f, 0.25f);
        animator1.setDuration(2000);
        animator1.setInterpolator(new LinearInterpolator());
        animator1.setRepeatCount(1);
        animator1.setRepeatMode(ValueAnimator.REVERSE);
        animator1.addListener(new AnimatorListenerAdapter() {

            @Override
            public void onAnimationRepeat(Animator animation) {
                textView.setText(R.string.rev_scale);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                textView.setText(R.string.done_scale);
            }
        });

        ObjectAnimator animator2 =
                ObjectAnimator.ofFloat(fishImage, "scaleY", 1f, 0.25f);
        animator2.setDuration(2000);
        animator2.setInterpolator(new LinearInterpolator());
        animator2.setRepeatCount(1);
        animator2.setRepeatMode(ValueAnimator.REVERSE);

        animSet.playTogether(animator1, animator2);
        textView.setText(R.string.start_scale);
        animSet.start();
    }

}