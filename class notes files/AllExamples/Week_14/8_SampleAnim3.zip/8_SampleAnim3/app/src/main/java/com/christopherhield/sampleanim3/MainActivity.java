package com.christopherhield.sampleanim3;

import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private ImageView leftCharacter, rightCharacter;
    private int leftScoreVal, rightScoreVal;
    private ConstraintLayout layout;
    public static int screenHeight;
    public static int screenWidth;
    private float groundLevel = 150;

    private Bitmap characterIdleBitmap;
    private Bitmap[] characterRunBitmaps;
    private Bitmap[] characterShootBitmaps;
    private Bitmap[] characterDeadBitmaps;

    private MediaPlayer intro;
    private boolean busy;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupFullScreen();

        getScreenDimensions();

        layout = findViewById(R.id.layout);

        addCharacters();

        intro = MediaPlayer.create(this, R.raw.intromusic);
        intro.start();

    }

    private void setupFullScreen() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void getScreenDimensions() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        screenHeight = displayMetrics.heightPixels;
        screenWidth = displayMetrics.widthPixels;
    }

    private void addCharacters() {

        Bitmap origBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.idle);
        characterIdleBitmap = Bitmap.createScaledBitmap(origBitmap, 482, 406, false);

        makeShootImages();
        makeRunImages();
        makeDeadImages();

        leftCharacter = new ImageView(this);
        leftCharacter.setImageBitmap(characterIdleBitmap);
        leftCharacter.setX(0);
        leftCharacter.setY(screenHeight - characterIdleBitmap.getHeight() - groundLevel);
        layout.addView(leftCharacter);

        rightCharacter = new ImageView(this);
        rightCharacter.setImageBitmap(characterIdleBitmap);
        rightCharacter.setX(screenWidth - (characterIdleBitmap.getWidth() * 0.75f));
        rightCharacter.setY(screenHeight - characterIdleBitmap.getHeight() - groundLevel + 20);
        rightCharacter.setScaleX(-1f);
        layout.addView(rightCharacter);
    }

    private void makeDeadImages() {
        int[] characterDeadResources = new int[]{R.drawable.dead1, R.drawable.dead2, R.drawable.dead3,
                R.drawable.dead4, R.drawable.dead5, R.drawable.dead6, R.drawable.dead7,
                R.drawable.dead8, R.drawable.dead9, R.drawable.dead10};
        characterDeadBitmaps = new Bitmap[characterDeadResources.length];
        for (int i = 0; i < characterDeadResources.length; i++) {
            Bitmap origBitmap = BitmapFactory.decodeResource(getResources(), characterDeadResources[i]);
            characterDeadBitmaps[i] = Bitmap.createScaledBitmap(origBitmap, 482, 406, false);
        }
    }

    private void makeShootImages() {
        int[] characterShootResources = new int[]{R.drawable.shoot1, R.drawable.shoot2, R.drawable.shoot3,
                R.drawable.shoot4, R.drawable.shoot5};
        characterShootBitmaps = new Bitmap[characterShootResources.length];
        for (int i = 0; i < characterShootResources.length; i++) {
            Bitmap origBitmap = BitmapFactory.decodeResource(getResources(), characterShootResources[i]);
            characterShootBitmaps[i] = Bitmap.createScaledBitmap(origBitmap, 482, 406, false);
        }
    }

    private void makeRunImages() {
        int[] characterRunResources = new int[]{R.drawable.run1, R.drawable.run2, R.drawable.run3,
                R.drawable.run4, R.drawable.run5, R.drawable.run6, R.drawable.run7, R.drawable.run8};
        characterRunBitmaps = new Bitmap[characterRunResources.length];
        for (int i = 0; i < characterRunResources.length; i++) {
            Bitmap origBitmap = BitmapFactory.decodeResource(getResources(), characterRunResources[i]);
            characterRunBitmaps[i] = Bitmap.createScaledBitmap(origBitmap, 482, 406, false);
        }
    }

    public void shoot(View v) {

        if (busy)
            return;
        busy = true;
        findViewById(R.id.button).setVisibility(View.INVISIBLE);

        if (intro.isPlaying())
            intro.stop();

        new Thread(new Runnable() {

            @Override
            public void run() {

                doSteps();

                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                doShoot();

                leftCharacter.setImageBitmap(characterIdleBitmap);
                rightCharacter.setImageBitmap(characterIdleBitmap);

                ImageView deadOne;
                if (Math.random() < 0.5) {
                    deadOne = leftCharacter;
                    rightScoreVal++;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ((TextView) findViewById(R.id.rightScore)).
                                    setText(String.format(Locale.getDefault(), "%d", rightScoreVal));
                        }
                    });
                } else {
                    deadOne = rightCharacter;
                    leftScoreVal++;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ((TextView) findViewById(R.id.leftScore)).
                                    setText(String.format(Locale.getDefault(), "%d", leftScoreVal));
                        }
                    });

                }

                doDead(deadOne);

                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                reset();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        findViewById(R.id.button).setVisibility(View.VISIBLE);
                    }
                });
                busy = false;
            }
        }).start();
    }

    private void reset() {
        leftCharacter.setImageBitmap(characterIdleBitmap);
        leftCharacter.setX(0);
        leftCharacter.setY(screenHeight - characterIdleBitmap.getHeight() - groundLevel);

        rightCharacter.setImageBitmap(characterIdleBitmap);
        rightCharacter.setX(screenWidth - (characterIdleBitmap.getWidth() * 0.75f));
        rightCharacter.setY(screenHeight - characterIdleBitmap.getHeight() - groundLevel + 20);
        rightCharacter.setScaleX(-1f);

    }

    private void doDead(final ImageView deadOne) {
        for (int i = 0; i < characterDeadBitmaps.length; i++) {

            final int index = i;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    deadOne.setImageBitmap(characterDeadBitmaps[index]);
                }
            });

            try {
                Thread.sleep(120);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    private void doShoot() {
        MediaPlayer mp1 = MediaPlayer.create(this, R.raw.shot);
        mp1.start();

        for (int i = 0; i < characterShootBitmaps.length; i++) {

            final int index = i;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    leftCharacter.setImageBitmap(characterShootBitmaps[index]);
                    rightCharacter.setImageBitmap(characterShootBitmaps[index]);
                }
            });

            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    private void doSteps() {
        MediaPlayer mp = MediaPlayer.create(this, R.raw.steps);
        mp.setPlaybackParams(mp.getPlaybackParams().setSpeed(2f));
        mp.start();

        for (int i = 0; i < characterRunBitmaps.length; i++) {
            final int index = i;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    leftCharacter.setImageBitmap(characterRunBitmaps[index]);
                    rightCharacter.setImageBitmap(characterRunBitmaps[index]);
                    leftCharacter.setX(leftCharacter.getX() + 10);
                    rightCharacter.setX(rightCharacter.getX() - 10);
                }
            });

            try {
                Thread.sleep(150);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
        leftCharacter.setImageBitmap(characterIdleBitmap);
        rightCharacter.setImageBitmap(characterIdleBitmap);
    }

}
