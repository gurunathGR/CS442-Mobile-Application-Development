package com.christopherhield.animexample;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    public static int screenHeight;
    public static int screenWidth;
    private ImageView character;
    private Bitmap[] playerWalkBitmaps;
    private int[] playerWalkResources;
    private Bitmap playerJumpBitmap;
    private boolean walking = false;
    private int count = 0;
    private ObjectAnimator jumpAnimator, rotateAnimator;
    private boolean jumping = false;
    private int xMod = 20;
    private int imageIncrement = 1;
    private boolean smallScale = true;
    private MediaPlayer walk, jump;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        playerWalkResources = new int[]{R.drawable.walk1, R.drawable.walk2, R.drawable.walk3,
                R.drawable.walk4, R.drawable.walk5, R.drawable.walk6, R.drawable.walk7,
                R.drawable.walk8, R.drawable.walk9, R.drawable.walk10};
        playerWalkBitmaps = new Bitmap[playerWalkResources.length];

        addCharacter();

        walk = MediaPlayer.create(this, R.raw.pim);
        walk.setLooping(true);

        jump = MediaPlayer.create(this, R.raw.jump);

    }

    public void addCharacter() {

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        screenHeight = displayMetrics.heightPixels;
        screenWidth = displayMetrics.widthPixels;

        character = new ImageView(this);
        character.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (smallScale) {
                    character.setScaleX(Math.signum(character.getScaleX()) * 1.5f);
                    character.setScaleY(1.5f);
                    character.setY(character.getY() - 100);
                    smallScale = false;
                } else {
                    character.setScaleX(Math.signum(character.getScaleX()) * 1f);
                    character.setScaleY(1f);
                    character.setY(character.getY() + 100);
                    smallScale = true;
                }
            }
        });
        ConstraintLayout layout = findViewById(R.id.layout);
        LinearLayout.LayoutParams params = new LinearLayout
                .LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        character.setLayoutParams(params);
        layout.addView(character);

        for (int i = 0; i < playerWalkResources.length; i++) {
            playerWalkBitmaps[i] = BitmapFactory.decodeResource(getResources(), playerWalkResources[i]);
        }
        playerJumpBitmap = playerWalkBitmaps[1];


        character.setImageBitmap(playerWalkBitmaps[0]);

        double ratio = 0.18;
        ViewGroup.LayoutParams layoutParams = character.getLayoutParams();
        layoutParams.height = (int) (playerWalkBitmaps[0].getHeight() * ratio);
        layoutParams.width = (int) (playerWalkBitmaps[0].getWidth() * ratio);
        character.setLayoutParams(layoutParams);
        character.setX(0);
        character.setY(screenHeight * 0.6f);
        character.setZ(1.0f);

        setupAnimators();

    }

    public void doWalk(View v) {


        if (walking) {
            walking = false;
            walk.pause();
            ((Button) findViewById(R.id.button1)).setText(R.string.walk);
        } else {
            walk.start();

            ((Button) findViewById(R.id.button1)).setText(R.string.stop);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    walking = true;
                    while (walking) {
                        if (!jumping) {
                            character.setImageBitmap(playerWalkBitmaps[count]);
                            count += imageIncrement;
                        }
                        character.setX(character.getX() + xMod);
                        try {
                            Thread.sleep(75);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if (count >= playerWalkBitmaps.length)
                            count = 0;

                        if (character.getX() >= screenWidth * 0.9f || character.getX() <= 0) {
                            xMod = -xMod;

                            character.setScaleX(-character.getScaleX());
                        }
                    }
                    character.setImageBitmap(playerWalkBitmaps[0]);

                }
            }).start();
        }
    }

    public void doJump(View v) {
        if (jumping)
            return;
        jump.start();
        jumping = true;
        character.setImageBitmap(playerJumpBitmap);
        jumpAnimator.start();
    }

    public void doFlip(View v) {
        if (jumping)
            return;
        jump.start();
        doJump(v);
        rotateAnimator.start();

    }

    public void doInvisible(View v) {

        if (character.getAlpha() == 1.0f) {
            walk.setPlaybackParams(walk.getPlaybackParams().setPitch(0.5f));

            character.setAlpha(0.4f);
        }
        else {
            walk.setPlaybackParams(walk.getPlaybackParams().setPitch(1f));

            character.setAlpha(1.0f);
        }
    }

    public void doFast(View v) {
        if (Math.abs(xMod) == 20) {
            if (walking)
                walk.setPlaybackParams(walk.getPlaybackParams().setSpeed(1.5f));

            xMod *= 2;
            imageIncrement = 3;
            ((Button)findViewById(R.id.button5)).setText(R.string.slow);
        } else {
            if (walking)
                walk.setPlaybackParams(walk.getPlaybackParams().setSpeed(1f));

            xMod /= 2;
            imageIncrement = 1;
            ((Button)findViewById(R.id.button5)).setText(R.string.fast);
        }

    }

    private void setupAnimators() {
        float startY = character.getY();
        jumpAnimator = ObjectAnimator.ofFloat(character, "y", startY, MainActivity.screenHeight * .2f);
        jumpAnimator.setDuration(800);
        jumpAnimator.setRepeatMode(ObjectAnimator.REVERSE);
        jumpAnimator.setRepeatCount(1);
        jumpAnimator.setInterpolator(new LinearInterpolator());
        jumpAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                jumping = false;
                character.setImageBitmap(playerWalkBitmaps[0]);
            }

        });

        rotateAnimator = ObjectAnimator.ofFloat(character, "rotation", 0, 360);
        rotateAnimator.setDuration(1600);
        rotateAnimator.setInterpolator(new LinearInterpolator());

    }

    public void doExit(View v) {
        walking = false;
        jumpAnimator.cancel();
        rotateAnimator.cancel();

        walk.stop();
        jump.stop();
        finish();
    }
}
