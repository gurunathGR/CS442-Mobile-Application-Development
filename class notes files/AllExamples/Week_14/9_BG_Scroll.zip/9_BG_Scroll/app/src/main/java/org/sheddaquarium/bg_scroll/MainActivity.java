package org.sheddaquarium.bg_scroll;

import android.animation.ValueAnimator;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    public static int screenHeight;
    public static int screenWidth;

    private ImageView backImageA, backImageB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getScreenDimensions();
        setupFullScreen();

        addBackImage();
    }

    private void getScreenDimensions() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        screenHeight = displayMetrics.heightPixels;
        screenWidth = displayMetrics.widthPixels;
    }

    private void setupFullScreen() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void addBackImage() {
        backImageA = new ImageView(this);
        backImageB = new ImageView(this);

        ConstraintLayout layout = findViewById(R.id.layout);
        LinearLayout.LayoutParams params = new LinearLayout
                .LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

        backImageA.setLayoutParams(params);
        backImageB.setLayoutParams(params);

        layout.addView(backImageA);
        layout.addView(backImageB);

        Bitmap backBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.background);
        double ratio = (double) screenHeight / (double) backBitmap.getHeight();
        backImageA.setImageBitmap(backBitmap);
        backImageB.setImageBitmap(backBitmap);

        ViewGroup.LayoutParams layoutParams = backImageA.getLayoutParams();
        layoutParams.height = (int) ((double) backBitmap.getHeight() * ratio);
        layoutParams.width = (int) ((double) backBitmap.getWidth() * ratio);

        backImageA.setLayoutParams(layoutParams);
        backImageB.setLayoutParams(layoutParams);

        backImageA.setZ(-1);
        backImageB.setZ(-1);

        animateBack();
    }

    public void animateBack() {

        long duration = 3000; // 3 sec for one complete image cycle

        ValueAnimator animator = ValueAnimator.ofFloat(1.0f, 0.0f);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.setDuration(duration);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                final float progress = (float) animation.getAnimatedValue();
                float width = backImageA.getWidth();
                float translationX = width * progress;
                backImageA.setTranslationX(translationX);
                backImageB.setTranslationX(translationX - width);
            }
        });
        animator.start();
    }

}
