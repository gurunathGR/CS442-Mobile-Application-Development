package com.christopherhield.gestures;

import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class TouchListener implements View.OnTouchListener {

    private static final String TAG = "TouchListener";
    private float dX, dY;

    @Override
    public boolean onTouch(View view, MotionEvent event) {

        view.performClick(); // For accessibility

        Log.d(TAG, "onTouch: " + event.toString());
        switch (event.getAction()) {

            case MotionEvent.ACTION_DOWN:

                dX = view.getX() - event.getRawX();
                dY = view.getY() - event.getRawY();
                break;

            case MotionEvent.ACTION_MOVE:
                view.animate()
                        .x(event.getRawX() + dX)
                        .y(event.getRawY() + dY)
                        .setDuration(150)
                        .rotationBy((int) (Math.random() * 90))
                        .start();
                break;
            default:
                return false;
        }
        return false;
    }
}
