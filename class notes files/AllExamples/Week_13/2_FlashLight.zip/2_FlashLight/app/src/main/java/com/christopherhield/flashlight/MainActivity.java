package com.christopherhield.flashlight;

import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private CameraManager mCameraManager;
    private String mCameraId;
    private Switch onOffSwitch;
    private Button flashButton;
    private View layout;

    private boolean lightIsOn = false;
    private boolean flashIsLit = false;
    private boolean flashWasOn = false;
    private boolean flashMode = false;

    private Vibrator vibrator;
    private long[] vibOn = new long[]{0, 300};
    private long[] vibOff = new long[]{0, 100};
    private long[] vibFlash = new long[]{0, 100, 50, 100, 50, 100, 50, 100};
    private long[] vibErr = new long[]{0, 1000};

    private static final long FLASH_LEN = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout = findViewById(R.id.layout);
        onOffSwitch = findViewById(R.id.switch1);
        flashButton = findViewById(R.id.flashButton);

        onOffSwitch.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        switchChange();
                    }
                });

        checkIfFlashIsPresent();

        // Ok - we have a flash

        vibrator = (Vibrator) getApplicationContext().getSystemService(Context.VIBRATOR_SERVICE);

        mCameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            if (mCameraManager != null) {
                mCameraId = mCameraManager.getCameraIdList()[0];
                lightIsOn = true;
                lightOn();
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

    }

    private void checkIfFlashIsPresent() {
        boolean isFlashAvailable = getApplicationContext().getPackageManager()
                .hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);

        if (!isFlashAvailable) {
            AlertDialog alert = new AlertDialog.Builder(MainActivity.this)
                    .create();
            alert.setTitle("Unsupported!!");
            alert.setMessage("Your device doesn't support flash light!");
            alert.setButton(DialogInterface.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    // closing the application
                    finish();
                }
            });
            alert.show();
        }
    }
    private void doVibrate(long[] pattern) {
        vibrator.vibrate(pattern, -1);
    }

    @Override
    protected void onPause() {
        flashWasOn = flashMode;
        if (flashMode)
            flashMode = false;
        turnOffFlashLight();
        super.onPause();
    }

    @Override
    protected void onResume() {
        if (lightIsOn)
            turnOnFlashLight();
        if (flashWasOn) {
            flashMode = true;
            startFlash();
        }

        super.onResume();

    }

    public void switchChange() {
        if (flashMode)
            setFlashOff();

        if (!lightIsOn) {
            doVibrate(vibOn);
            lightOn();
        } else {
            doVibrate(vibOff);
            lightOff();
        }

    }

    private void lightOff() {
        turnOffFlashLight();
        onOffSwitch.setTrackTintList(ColorStateList.valueOf(Color.RED));
        onOffSwitch.setThumbTintList(ColorStateList.valueOf(Color.RED));
        layout.setBackgroundResource(R.color.offBG);
        onOffSwitch.setText(R.string.off_text);
        lightIsOn = false;
    }

    private void lightOn() {
        turnOnFlashLight();
        onOffSwitch.setText(R.string.on_text);
        onOffSwitch.setTrackTintList(ColorStateList.valueOf(Color.GREEN));
        onOffSwitch.setThumbTintList(ColorStateList.valueOf(Color.GREEN));
        layout.setBackgroundResource(R.color.onBG);
        lightIsOn = true;

        setFlashOff();

    }

    public void turnOnFlashLight() {
        try {
            mCameraManager.setTorchMode(mCameraId, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void turnOffFlashLight() {
        try {
            mCameraManager.setTorchMode(mCameraId, false);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void flashClicked(View v) {

        if (lightIsOn) {
            doVibrate(vibErr);
            Toast.makeText(this,
                    "Flash cannot be enabled while Light is ON", Toast.LENGTH_LONG).show();
            return;
        }
        if (flashMode) {
            doVibrate(vibOff);
            setFlashOff();
        } else {
            doVibrate(vibFlash);
            setFlashOn();
        }

    }

    private void setFlashOn() {
        flashButton.setText(R.string.flash_on);
        flashButton.setTextColor(Color.GREEN);
        flashMode = true;
        startFlash();
    }

    private void setFlashOff() {
        flashButton.setText(R.string.flash_off);
        flashButton.setTextColor(Color.RED);
        flashMode = false;
    }

    private void startFlash() {
        Runnable r = new Runnable() {
            @Override
            public void run() {
                // Flash while flash mode is on
                while (flashMode) {
                    if (flashIsLit) {
                        turnOffFlashLight();
                        flashIsLit = false;
                    } else {
                        turnOnFlashLight();
                        flashIsLit = true;
                    }

                    try {
                        Thread.sleep(FLASH_LEN);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                // flash mode is done
                turnOffFlashLight();
                flashIsLit = false;

                // If the light is supposed to be onm turn it on
                if (lightIsOn)
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            lightOn();
                        }
                    });

            }
        };
        new Thread(r).start();
    }
}
