package com.christopherhield.fragments;

import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.Collections;


public class ZooAnimal implements Comparable<ZooAnimal> {

    private String name;
    private String latin;
    private String height;
    private String weight;
    private String distribution;
    private String details;
    private String habitat;
    private String wild_diet;
    private String zoo_diet;

    // Static list used to hold all existing ZooAnimal objects
    private static ArrayList<ZooAnimal> allAnimals = new ArrayList<>();


    // Add a new animal to the static list of animals
    static void addNew(String nameIn, String latinIn, String heightIn, String weightIn,
                       String distributionIn, String habitatIn, String wild_dietIn, String zoo_dietIn, String detailsIn) {
        ZooAnimal za = new ZooAnimal(nameIn, latinIn, heightIn, weightIn, distributionIn, habitatIn, wild_dietIn, zoo_dietIn, detailsIn);
        allAnimals.add(za);
        Collections.sort(allAnimals);
    }

    // Clear the static list of animals
    static void clear() {
        allAnimals.clear();
    }

    // Accessor method to get/return a ZooAnimal from the allAnimals list
    static ZooAnimal get(int idx) {
        return allAnimals.get(idx);
    }

    // Return a string array of all ZooAnimal names
    static String[] getAllNames() {
        String[] names = new String[allAnimals.size()];
        for (int i = 0; i < allAnimals.size(); i++) {
            names[i] = allAnimals.get(i).getName();
        }
        return names;
    }

    //
    // Non-static content

    private ZooAnimal(String nameIn, String latinIn, String heightIn, String weightIn, String distributionIn, String habitatIn, String wild_dietIn, String zoo_dietIn, String detailsIn) {
        name = nameIn;
        latin = latinIn;
        height = heightIn;
        weight = weightIn;
        distribution = distributionIn;
        details = detailsIn;
        habitat = habitatIn;
        wild_diet = wild_dietIn;
        zoo_diet = zoo_dietIn;
    }


    // Accessors
    String getWild_diet() {
        return wild_diet;
    }

    String getZoo_diet() {
        return zoo_diet;
    }

    String getHabitat() {
        return habitat;
    }

    String getHeight() {
        return height;
    }

    String getWeight() {
        return weight;
    }

    String getDistribution() {
        return distribution;
    }

    String getName() {
        return name;
    }

    String getDetails() {
        return details;
    }

    String getLatin() {
        return latin;
    }

    @Override
    public int compareTo(@NonNull ZooAnimal o) {
        return name.compareTo(o.name);
    }
}
