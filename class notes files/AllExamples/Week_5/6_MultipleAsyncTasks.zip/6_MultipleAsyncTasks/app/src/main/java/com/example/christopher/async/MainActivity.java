package com.example.christopher.async;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView statusA, statusB;
    private ProgressBar progressBarA, progressBarB;
    private static final long taskTime = 15_000L;

    private static final String TAG = "MainActivity";

    private boolean runningA = false, runningB = false;


    // To run more than 1 async task, you need THREAD_POOL_EXECUTOR (see below)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusA = findViewById(R.id.statusA);
        progressBarA = findViewById(R.id.progressBarA);

        statusB = findViewById(R.id.statusB);
        progressBarB = findViewById(R.id.progressBarB);

    }

    public void doAsyncA(View v) {
        if (runningA) {
            Toast.makeText(this, "Wait for Async Task A to complete", Toast.LENGTH_SHORT).show();
            return;
        }

        statusA.setText("Async Task A ACTIVE");
        runningA = true;

        new MyAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,"A");
    }

    public void doAsyncB(View v) {
        if (runningB) {
            Toast.makeText(this, "Wait for Async B Task to complete", Toast.LENGTH_SHORT).show();
            return;
        }

        statusB.setText("Async Task B ACTIVE");
        runningB = true;

        new MyAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,"B");
    }

    public void doMainThreadWork(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Main Thread");
        builder.setMessage("This is running in the Main Thread");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // Nothing to do - just close
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void openSecondActivity(View v) {
        Intent intent = new Intent(MainActivity.this, SecondActivity.class);
        startActivity(intent);
    }

    /////////////
    class MyAsyncTask extends AsyncTask<String, Integer, String> { //  <Parameter, Progress, Result>

        @Override
        protected String doInBackground(String... params) {

            Log.d(TAG, "doInBackground: " + params[0]);
            try {
                long interval = taskTime / 10;
                for (int i = 0; i < 10; i++) {
                    Log.d(TAG, "doInBackground: " + params[0] + ", " + interval);
                    Thread.sleep(interval);
                    publishProgress((int) params[0].charAt(0), i + 1);
                }

            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            return params[0];
        }


        @Override
        protected void onPostExecute(String string) {
            Toast.makeText(MainActivity.this, "AsyncTask " + string + " has finished", Toast.LENGTH_SHORT).show();

            if (string.equals("A")) {
                runningA = false;
                statusA.setText("Async Task A INACTIVE");
            }
            if (string.equals("B")) {
                runningB = false;
                statusB.setText("Async Task B INACTIVE");
            }
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            char c = (char) values[0].intValue();
            int progress = values[1];

            if (c == 'A')
                progressBarA.setProgress(progress);
            if (c == 'B')
                progressBarB.setProgress(progress);
        }
    }

}
