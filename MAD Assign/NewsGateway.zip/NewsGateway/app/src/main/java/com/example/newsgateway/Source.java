package com.example.newsgateway;

import java.io.Serializable;

public class Source implements Serializable {

    String sId;
    String sUrl;
    String sName;
    String sCategory;

    public String getsId()
    {
        return sId;
    }

    public void setsId(String sId)
    {
        this.sId = sId;
    }

    public String getsUrl()
    {
        return sUrl;
    }

    public void setsUrl(String sUrl)
    {
        this.sUrl = sUrl;
    }

    public String getsName()
    {
        return sName;
    }

    public void setsName(String sName)
    {
        this.sName = sName;
    }

    public String getsCategory()
    {
        return sCategory;
    }

    public void setsCategory(String sCategory)
    {
        this.sCategory = sCategory;
    }
}

