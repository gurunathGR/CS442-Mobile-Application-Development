package com.example.gr.temperatureconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    double ipValGR=0.0, ansGR = 0.0;
    RadioButton Fah2Cel,Cel2Fah;
    EditText edtText;
    TextView hstry,fnlAns,heading, answerHeading;
    String l1="",l2="",hstryData="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        Toast.makeText(this, "WELCOME", Toast.LENGTH_SHORT).show();
        Fah2Cel = (RadioButton) findViewById(R.id.radioButtonF2C);
        Cel2Fah = (RadioButton) findViewById(R.id.radioButtonC2F);
        edtText = findViewById(R.id.userInput);
        fnlAns = findViewById(R.id.resultDisplay);
        heading = findViewById(R.id.textView3);
        answerHeading = findViewById(R.id.textView4);
        hstry = findViewById(R.id.historyDisplay);
    }
      @Override
      public void onSaveInstanceState(Bundle savedInstanceState)
      {

          savedInstanceState.putString("INPUT",edtText.getText().toString());
          savedInstanceState.putString("OUTPUT",fnlAns.getText().toString());
          savedInstanceState.putString("TEMP_VAL",hstry.getText().toString());

          super.onSaveInstanceState(savedInstanceState);
      }
      @Override
      public void onRestoreInstanceState(Bundle savedInstanceState)
      {
          super.onRestoreInstanceState(savedInstanceState);

          edtText.setText(savedInstanceState.getString("INPUT"));
          fnlAns.setText(savedInstanceState.getString("OUTPUT"));
          hstry.setText(savedInstanceState.getString("TEMP_VAL"));
      }
    public void radioClick(View v) {

        if (Fah2Cel.isChecked()) {
            l1="F";
            l2="C";
            heading.setText("Fahrenhiet Degrees");
            answerHeading.setText("Celsius Degrees");

            ansGR = ((ipValGR - 32) * 5) / 9;
        }
        else {
            l1="C";
            l2="F";
            heading.setText("Celsius Degrees");
            answerHeading.setText("Fahrenhiet Degrees");
            ansGR = (ipValGR * 1.8) + 32;
        }
    }

    public void tempConvert(View v) {

        try {
            ipValGR = Double.parseDouble(edtText.getText().toString());
        }

        catch (Exception e){
            Toast.makeText(this, "Please enter a number", Toast.LENGTH_SHORT).show();
            return;
        }

        radioClick(v);

        fnlAns.setText(String.format("%.1f", ansGR));

        hstryData = "    " + ipValGR + " " + l1 + " ==> " + String.format("%.1f", ansGR) + l2 + "\n" + hstryData;
        hstry.setMovementMethod(new ScrollingMovementMethod());
        hstry.setText(hstryData);


    }

    public void clear(View v) {

        hstry.setText("");
        edtText.setText("");
        fnlAns.setText("");



    }
}

